/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package straten.xml;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.HashSet;
import straten.bo.Gemeente;
import straten.bo.Stadsdeel;
import straten.bo.Straat;
import straten.bo.StraatDeel;
import straten.bo.Wijk;

/**
 *
 * @author tiwi
 */
public class XMLGemeente implements Gemeente {

    // hulpmap om stadsdelen op naam te zoeken
    private final Map<String, Stadsdeel> mapStadsdelen;
    // hulpmap om wijken op nr te zoeken
    private final Map<Integer, Wijk> mapWijken;
    // hulpmap om straten op naam te zoeken
    private final Map<String, Straat> mapStraten;

    public XMLGemeente(String bestand) {
        mapStraten = new HashMap<>();
        mapWijken = new HashMap<>();
        mapStadsdelen = new HashMap<>();

        /* VUL AAN: overloop alle straten (<element>...</element>) en bewaar alle
         * informatie uit het element en zijn kinderen in de juiste objecten en mappen
         * maak hierbij gebruik van de onderstaande hulpmethodes.        
         */
    }

    /**
     * Geeft alle stadsdelen terug. De stadsdelen bevatten informatie over
     * wijken, straten, sectoren en straatdelen.
     *
     * Deze methode wordt gebruikt door de GUI.     
     *
     * @return een verzameling van stadsdelen
     */
    @Override
    public Set<Stadsdeel> getStadsdelen() {
        Set<Stadsdeel> stadsdelen = new HashSet<>();
        stadsdelen.addAll(mapStadsdelen.values());
        return stadsdelen;
    }

    /**
     * Zoekt een stadsdeel in de map of maakt een nieuw aan. Een hulpmethode die
     * in de hashmap mapStadsdelen een stadsdeel met de opgegeven naam zoekt,
     * als er geen stadsdeel gevonden wordt, dan wordt er een nieuw aangemaakt
     * en toegevoegd aan de hashmap.
     *
     * @param naamStadsdeel de naam van het te zoeken stadsdeel
     * @return het gevonden of nieuw aangemaakte stadsdeel
     */
    private Stadsdeel bepaalStadsdeel(String naamStadsdeel) {
        Stadsdeel stadsdeel;
        if (mapStadsdelen.containsKey(naamStadsdeel)) {
            stadsdeel = mapStadsdelen.get(naamStadsdeel);
        } else {
            stadsdeel = new Stadsdeel();
            stadsdeel.setNaam(naamStadsdeel);
            stadsdeel.setWijken(new HashSet<>());
            mapStadsdelen.put(naamStadsdeel, stadsdeel);
        }
        return stadsdeel;
    }

    /**
     * Zoekt een wijk in de map of maakt een nieuwe aan. Een hulpmethode die in
     * de hashmap mapWijken een wijk met het opgegeven nummer zoekt, als er geen
     * wijk gevonden wordt, dan wordt er een nieuwe aangemaakt en toegevoegd aan
     * de hashmap.
     *
     * @param wijkNr de nummer van de te zoeken wijk
     * @param naam de naam van de te zoeken wijk
     * @return de gevonden of nieuw aangemaakte wijk
     */
    private Wijk bepaalWijk(String wijkNr, String naam) {
        Wijk wijk;
        Integer nr = new Integer(wijkNr);
        if (mapWijken.containsKey(nr)) {
            wijk = mapWijken.get(nr);
        } else {
            wijk = new Wijk();
            wijk.setNaam(naam);
            wijk.setId(nr);
            wijk.setStraten(new HashSet<>());
            mapWijken.put(nr, wijk);
        }
        return wijk;
    }

    /**
     * Zoekt een straat in de map of maakt een nieuwe aan. Een hulpmethode die
     * in de hashmap mapStraten een straat met de opgegeven naam zoekt, als er
     * geen straat gevonden wordt, dan wordt er een nieuwe aangemaakt en
     * toegevoegd aan de hashmap.
     *
     * @param straatNaam de naam van de te zoeken straat
     * @param postcode de postcode van de deelgemeente waarin de straat ligt
     * @param straatCode de code van de straat
     * @return de gevonden of nieuw aangemaakte straat
     */
    private Straat bepaalStraat(String straatNaam, String postcode, String straatCode) {
        Straat straat;
        if (mapStraten.containsKey(straatNaam)) {
            straat = mapStraten.get(straatNaam);
        } else {
            straat = new Straat();
            straat.setNaam(straatNaam);
            straat.setCode(straatCode);
            straat.setPostcode(Integer.parseInt(postcode));
            straat.setSectoren(new HashSet<>());
            mapStraten.put(straatNaam, straat);
        }
        return straat;
    }

    /**
     * Maakt een nieuw straatdeel aan. Een hulpmethode die een nieuw straatdeel
     * aan.
     *
     * @param van het nummer of de nummercode waarmee het straatdeel begint
     * @param tot het nummer of de nummercode waarmee het straatdeel eindigt
     * @return het aangemaakte straatdeel
     */
    private StraatDeel maakStraatDeel(String van, String tot) {
        StraatDeel straatdeel = new StraatDeel();
        straatdeel.setVan(van);
        straatdeel.setTot(tot);
        return straatdeel;
    }

}