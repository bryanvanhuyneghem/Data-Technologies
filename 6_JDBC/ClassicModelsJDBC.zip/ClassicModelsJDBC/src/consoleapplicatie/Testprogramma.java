/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package consoleapplicatie;

public class Testprogramma {

    public static void main(String[] args) {
        // TODO code application logic here
        try {
            //IDataStorage database = ...;

        } catch (Exception ex) {
            //
        }

    }

}
