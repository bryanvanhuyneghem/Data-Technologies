CALL SYSCS_UTIL.SYSCS_IMPORT_TABLE(null,'CUSTOMERS','c:\Temp\datafiles\customers.csv',';','"',null,0);
CALL SYSCS_UTIL.SYSCS_IMPORT_TABLE(null,'EMPLOYEES','C:\\temp\\datafiles\\employees.txt',',','"',null,0);
CALL SYSCS_UTIL.SYSCS_IMPORT_TABLE(null,'OFFICES','C:\\temp\\datafiles\\offices.txt',',','"',null,0);
CALL SYSCS_UTIL.SYSCS_IMPORT_TABLE(null,'ORDERDETAILS','C:\\temp\\datafiles\\orderdetails.txt',',','"',null,0);
CALL SYSCS_UTIL.SYSCS_IMPORT_TABLE(null,'ORDERS','C:\\temp\\datafiles\\Orders.csv',';','"',null,0);
CALL SYSCS_UTIL.SYSCS_IMPORT_TABLE(null,'PAYMENTS','C:\\temp\\datafiles\\payments.txt',',','"',null,0);
CALL SYSCS_UTIL.SYSCS_IMPORT_TABLE(null,'PRODUCTS','C:\\temp\\datafiles\\products.txt',';','"',null,0);